class Person {
    private name: string;
    private yearOfBirth: number;

    constructor(name: string, yearOfBirth: number) {
        this.name = name;
        this.yearOfBirth = yearOfBirth;
    }

    getName(): string {
        return this.name;
    }

    getYearOfBirth(): number {
        return this.yearOfBirth;
    }

    getAge(currentYear: number): number {
        return currentYear - this.yearOfBirth;
    }
}

export class Calendar {
    private currentYear: number;

    constructor(currentYear: number) {
        this.currentYear = currentYear;
    }
    getCurrentYear(): number {
        return this.currentYear;
    }
}

let  person1= new Person("John", 2005);
let  person2 = new Person("koeuk", 2020);
let Calendars = new Calendar(2023);
let age1 = Calendars.getCurrentYear()-person1.getYearOfBirth();
let age2 = Calendars.getCurrentYear()-person2.getYearOfBirth();
console.log(age1)
console.log(age2)
