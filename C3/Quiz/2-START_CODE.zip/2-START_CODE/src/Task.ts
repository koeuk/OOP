export class Task {
    constructor(private title: string, private description: string, private completed: boolean = false) { }
    getTitle(): string { return this.title; }
    getDescription(): string { return this.description; }
    getCompleted(): boolean { return this.completed; }
}