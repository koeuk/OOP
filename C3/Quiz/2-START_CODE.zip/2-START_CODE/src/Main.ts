import { Task } from "./Task";
import { TaskList } from "./TaskList";


let task1 = new Task("Task 1", "Description 1");
let task2= new Task("Task 2", "Description 2");
let taskList = new TaskList();

taskList.getCompletedTasks().push(task1);
// taskList.getCompletedTasks().push(task2);
taskList.addTask(task1);
taskList.getTasks();
taskList.getIncompleteTasks()[2];

console.log(taskList); // TaskList {tasks: Array(0), completedTasks: Array(1)}
console.log(task1);
console.log(task2);
