import { Task } from "./Task";

export class TaskList {
    private tasks: Task[] = [];
    // add tasks
    addTask(task: Task): void {
        this.tasks.push(task);
    }
    //get tasks
    getTasks(): Task[] {
        return this.tasks;
    }
    //get tasks is completed
    getCompletedTasks(): Task[] {
        return this.tasks ;
    }
    //get  tasks not completed
    getIncompleteTasks(): Task[] {
        return this.tasks = [];
    }
}
